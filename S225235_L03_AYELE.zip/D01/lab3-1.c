#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <stdbool.h>
#include <time.h>
#include <sys/time.h>

#include <assert.h>
#include <errno.h>
#include<pthread.h>

#define NLOOP 10000
#define NORMAL_BUFF_MAX 8000
#define URGENT_BUFF_MAX 2000

long long ms;
sem_t *semP;
int nc;
int nnormal, nurgent;
bool arr[NLOOP]={0};

typedef struct Buffer{
	long long * buffer;
	int count;
} Buffer;

Buffer *normal, *urgent;

long long current_timestamp() {
	struct timeval te;
	gettimeofday(&te, NULL); // get current time
	long long milliseconds = te.tv_sec*1000LL + te.tv_usec/1000;
	return milliseconds;
}

static void * producerThread(void * argp){

	struct timespec ts;
	int i, t, r;
	
	for(i=0; i < NLOOP; i++){
		t = ((rand() % 10 - 1 + 1) + 1);
		ts.tv_nsec = t * 1000000;
		nanosleep(&ts, NULL);
		ms = current_timestamp();
		
		/* Intializes random number generator */
   		srand(time(NULL));
		r = (rand() % 10000);
		//check if r was generated before
		if(!arr[r]) {
			printf("r = %d\n",r);
			if(r<=8000){
				//normal buffer			
				printf("PRODUCER: putting %lld in buffer NORMAL\n",ms);
				normal->buffer[normal->count] = ms;
				normal->count++;
				nc++; nnormal++;
				sem_post(semP);
			} else {
				printf("PRODUCER: putting %lld in buffer URGENT\n",ms);
				urgent->buffer[urgent->count] = ms;
				urgent->count++;
				nc++; nurgent++;
				sem_post(semP);
			}
		} else{
				 i--;
		}
		//printf("r = %d\n",r);
		arr[r]=1;
	}

}

static void * consumerThread(void * argc){

	while(nc < NLOOP){
		struct timespec ts;
		ts.tv_nsec = 10 * 1000000;
		nanosleep(&ts, NULL);
		//sleep(2);
		sem_wait(semP);
		//check urgent first
		long long val;
		if(urgent->count > 0){
			val = urgent->buffer[urgent->count-1];
			printf("CONSUMER: retrieved ms: %lld from URGENT buffer\n", val);
		} else{
			val = normal->buffer[normal->count-1];
			printf("CONSUMER: retrieved ms: %lld from NORMAL buffer\n", val);
		}
	}
}

void buff_init(){
	normal = (Buffer *)malloc(sizeof(Buffer));
	urgent = (Buffer *)malloc(sizeof(Buffer));
	
	normal->buffer = (long long *)malloc(NORMAL_BUFF_MAX * sizeof(long long));
	urgent->buffer = (long long *)malloc(URGENT_BUFF_MAX * sizeof(long long));
	
	normal->count = 0;
	urgent->count = 0;
}

int main(int argc, char *argv[]) {

	buff_init();
	semP = (sem_t *)malloc(sizeof(sem_t));
	sem_init(semP, 0, 0);
	nc = 0;	//used as loop variable for consumer thread
	nnormal = 0; nurgent = 0;
	pthread_t th_p,th_c;
	pthread_create(&th_p, NULL, producerThread, (void *)NULL);
	pthread_create(&th_c, NULL, consumerThread, (void *)NULL);
	
	
	
	pthread_join(th_p, NULL);
	pthread_join(th_c, NULL);
	
	printf("Normal served: %d Urgent served: %d\n", nnormal, nurgent);
}
